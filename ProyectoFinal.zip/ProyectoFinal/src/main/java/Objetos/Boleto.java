
package Objetos;

/**
 *
 * @author Alexs
 */
public class Boleto {
    
    private int numPasaporte;
    private Vuelo vuelo;
    
    
    
}
