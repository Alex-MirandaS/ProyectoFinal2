
package Programa;

import java.io.IOException;

/**
 *
 * @author Alexs
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Principal principal = new Principal();
        principal.iniciar();
     
    }
    
}
